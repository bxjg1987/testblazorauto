建议：开大音量、1.5倍速观看

# 资源
    后端源码：https://gitee.com/bxjg1987/abp
    后台前端源码：https://gitee.com/bxjg1987/front
    项目基本介绍和运行：https://www.bilibili.com/video/BV1wt4y1e7V2
    业务模块开发：https://www.bilibili.com/video/BV1b5411L7Hf
    其它视频：https://space.bilibili.com/314047707
    在线demo：http://web1.cqyuzuji.com:9000/  账号：admin  密码：123qwe

# 场景
    基本场景
    多种工单类型
    多种创建方式
    状态流转

demo演示

# abp模块和业务模块
    概念：abp的模块就不说了，说说业务模块的概念
    问题：业务模块之间的依赖不干净
        一代没有业务模块
        vNext的问题  
# 目标
    实践DDD
    干净、可复用、可扩展的业务模块

# 总体思路
    抽象+默认实现
    如何集成
    如何扩展

# 源码走一走
